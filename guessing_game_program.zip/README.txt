
# Guessing Game Program

This is a simple Python program where the computer generates a random number between 1 and 100, and the user tries to guess it.

## How to Use

1. Run the program.
2. Enter your guesses when prompted.
3. The program will tell you if your guess is too high or too low.
4. Keep guessing until you find the correct number.
5. The program will display how many attempts you took to guess the number correctly.

## Requirements

- Python 3.x

## Example

Welcome to the Guessing Game!
I'm thinking of a number between 1 and 100. Try to guess it!
Enter your guess: 50
Too low! Try again.
Enter your guess: 75
Too high! Try again.
...
Congratulations! You guessed the number in 6 attempts.

## Run the Program

```bash
python guessing_game.py
```
